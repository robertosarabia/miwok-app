package com.example.android.miwok;

/**
 * {@Link Word} represents a vocabulary word that the user wants to lean.
 * It contains a default translation and a Miwok translation for each word.
 */
public class Word {

    private static final int NO_IMAGE_PROVIDED = -1;
    /**
     * Default translation for the word
     */
    private String mDefaultTranslation;
    /**
     * Miwok translation for the word
     */
    private String mMiwokTranslation;
    /**
     * Image resource ID for word
     */
    private int mImageResourceId = NO_IMAGE_PROVIDED;
    /**
     * Audio resource ID for word
     */
    private int mAudioResourceId;

    /**
     * Create a Word object.
     *
     * @param defaultTranslation is the default language (English) translation of the word
     * @param miwokTranslation   is the Miwok language translation of the word
     * @param audioResourceId    is the raw resource ID associated with the word
     */
    public Word(String defaultTranslation, String miwokTranslation, int audioResourceId) {
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mAudioResourceId = audioResourceId;
    }

    /**
     * Create a Word object with image
     *
     * @param defaultTranslation is the default language (English) translation of the word
     * @param miwokTranslation   is the Miwok language translation of the word
     * @param imageResourceId    is the drawable resource ID associated with the word
     * @param audioResourceId    is the raw resource ID associated with the word
     */
    public Word(String defaultTranslation, String miwokTranslation, int imageResourceId, int audioResourceId) {
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mImageResourceId = imageResourceId;
        mAudioResourceId = audioResourceId;
    }

    /**
     * Get the default translation of the word
     */
    public String getDefaultTranslation() {
        return mDefaultTranslation;
    }

    /**
     * Get the Miwok translation of the word
     */
    public String getMiwokTranslation() {
        return mMiwokTranslation;
    }

    /**
     * Get the image resource ID of the word
     */
    public int getImageResourceId() {
        return mImageResourceId;
    }

    /**
     * Get the audio resource ID of the word
     */
    public int getAudioResourceId() {
        return mAudioResourceId;
    }

    /**
     * Returns whether or not a word has an image
     */
    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }
}
